<template>
    <page-component isActive="about">
        <section>
            <div class="max-w-7xl mx-auto">
                <div class="h-96 bg-gradient-to-bl from-blue-400 to-indigo-700 rounded">
                    <div class="pt-56 text-center text-white">
                        <h1 class="text-4xl">Over Mij</h1>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-10">
            <div class="max-w-7xl mx-auto text-gray-700 px-4 lg:px-0">
                <h2 class="text-2xl font-semibold text-black">
                    Waarom programmeren!?
                </h2>

                <p class="py-2">
                    Al sinds jongs af aan toon ik interesse in het omgaan met een computer. Allereest begon ik met het
                    spelen van spellen (offline). Ken je die tijd nog? Met een inbelverbinding...
                </p>

                <p class="py-2">
                    Toen we uiteindelijk de mogelijkheid kregen om online te kunnen spelen, kwam ik in een spel terecht,
                    waarbij ze modificaties gebruikten (C++). Op oogslag raakte ik hieraan geobsedeerd en moest en zou dit
                    zelf ook kunnen.
                </p>

                <p class="py-2">
                    Na flink wat pogingen was het uiteindelijk gelukt. Dat was ook het moment dat ik in de toekomst hiermee
                    verder wou gaan. In 2009 had ik het voortgezet onderwijs afgerond en ben ik een opleiding Applicatie & Media- ontwikkeling
                    begonnen. Omdat ik voorheen al zelfkennis had opgedaan met programmeren verliep de opleiding niet soepel.
                    De docenten wisten niet wat ze met mij aan moesten, omdat ik overal al een antwoord op had.
                </p>

                <p class="py-2">
                    Ook begonnen mijn cijfers langzaam achteruit te gaan, tot het moment dat ik had besloten om te stoppen
                    met de opleiding medio 2012. Met de redenen dat ik geen uitdaging had en dat de docenten niet wisten wat ze met mij aan moesten.
                </p>

                <h2 class="text-2xl font-semibold text-black pt-4">
                    Wat nu?
                </h2>

                <p class="py-2">
                    Nu ben ik officieel een schoolverlater... Met bovenstaande reden heb ik mijn best gedaan, helaas tevergeefs, om aan een
                    baan te komen als ontwikkelaar. Na verschillende sollicitaties heb ik besloten om verder te gaan in de horeca. Bijkomend
                    dat ik in de tussentijd zelf verder kennis op deed op het programmeer gebied.
                </p>

                <h2 class="text-2xl font-semibold text-black pt-4">
                    Werken in de horeca?
                </h2>

                <p class="py-2">
                    Ik vind het super leuk om met mensen (oftewel gasten in horeca term) en ze een leuke dag te laten beleven. De klant
                    is koning! Tijdens het werken heb ik verschillende functies gehad. Begleider van grote groepen, barman, chef tot aan eerste medewerker.
                </p>

                <p class="py-2">
                    Ik vind het super leuk om met mensen (oftewel gasten in horeca term) en ze een leuke dag te laten beleven. De klant
                    is koning! Tijdens het werken heb ik verschillende functies gehad. Van begleider van grote groepen, barman, chef tot aan eerste medewerker.
                </p>

                <p class="py-2">
                    Ook al had ik het goed naar mijn zin, ontbrak er voor mijn gevoel toch nog iets. Ik wilde dolgraag een software ontwikkelaar worden,
                    omdat ik een schoolverlater was zonder een diploma kreeg ik niet de kans om dit beroep te kunnen beoefenen.
                </p>

                <h2 class="text-2xl font-semibold text-black pt-4">
                    Back2School <span class="text-base text-gray-600">nog niet</span>
                </h2>

                <p class="py-2">
                    Eind 2016 heb ik besloten om, wanneer het nieuwe schooljaar begint, weer terug te gaan in de schoolbanken.
                    Januari 2017 heb ik afscheid genomen van mijn horecabaan en wou ik van de vrijheid genieten.
                </p>

                <p class="py-2">
                    23 maart 2017, de dag dat het spel PlayerUnknown's Battlegrounds uit kwam! Het eerste Battle Royale spel dat
                    ik speelde. Niet wetende dat ik hier +1.000 uur in zou investeren binnen 6 maanden tijd.
                </p>

                <p class="py-2">
                    Na 10-tallen uren het spel gespeeld te hebben, kwam er een bekendmaking dat mensen zichzelf konden opgeven
                    om toegang te krijgen tot Custom Games. Custom Games geef de host (eigenaar) de mogelijkheid om bepaalde
                    onderdelen in het spel aan te passen. Na een week kreeg ik eindelijk bericht dat ik was geaccepteerd!
                </p>

                <p class="py-2">
                    Maar wat heb je er nu eigenlijk aan als je geen 99 andere spelers kan vinden. Dit was het moment dat
                    ik bij mezelf dacht om te gaan streamen op Twitch.
                </p>

                <h2 class="text-2xl font-semibold text-black pt-4">
                    Twitch <span class="text-base text-gray-600">#streamingplatform</span>
                </h2>

                <p class="py-2">
                    Sinds dag 1 van het streamen trok het een groot aantal mensen aan. Ze vonden het leuk om te spelen met
                    aangepaste spelinstellingen! Mijn kanaal groeide uit tot ~10.000 volgers binnen 2 maanden.
                </p>

                <p class="py-2">
                    De hele dag spelletjes spelen, mensen entertainen en ook nog eens geld verdienen! Is dat niet ieder
                    zijn droom? Nou, niet voor mij. Ik miste namelijk nog het onderdeel programmeren. Eenmaal aangekomen in
                    augustus ben ik wederom begonnen met dezelfde opleiding.
                </p>

                <h2 class="text-2xl font-semibold text-black pt-4">
                    Diploma!
                </h2>

                <p class="py-2">
                    Tussen 2017 - 2020 heb ik alles neergelegd en ben ik volledig voor mijn diploma gegaan. Gelukkig had ik
                    een mentor, tevens ook de vakdocent die programmeer lessen gaf, die begreep dat ik voor liep op mijn klasgenoten.
                </p>

                <p class="pb-2 text-sm text-gray-500 italic">
                    In de tijd tussen het werken in de horeca en het streamen had ik het nooit opgegeven om stil te staan in de
                    programmeer wereld. Bijleren vindt ik belangrijk en dat deed ik ook. Frameworks zoals Laravel, React en Vue kwamen
                    zelfs aan bod!
                </p>

                <p class="py-2">
                    In de 3 jaar dat ik weer op school had gezeten heb ik 3x een stage periode gehad. Deze heb ik allemaal
                    netjes afgerond met een goed en voldoendes. Ook heb ik nu eindelijk mijn diploma behaald.
                </p>

                <h2 class="text-2xl font-semibold text-black pt-4">
                    Diploma behaald, werk binnen no time?
                </h2>

                <p class="py-2">
                    Dat viel me toch nog vies tegen. Na verschillende sollicitatie gesprekken te hebben gehad in de regio,
                    kreeg ik bij alle te horen dat ze eigelijk op zoek waren naar iemand met meer kennis en werk-ervaring.
                </p>

                <p class="py-2">
                    Dit kwam, omdat de meeste personeelsleden vanuit thuis werkten (Covid-19) en het hen niet verstandig leek, om een
                    starter te introduceren in het vak.
                </p>

                <p class="py-2">
                    Met geluk had ik op dat moment nog contact met mijn stagebegeleider van het eerste en tweede schooljaar. Zij vroegen
                    of ik misschien zin had om een keer op de koffie kon komen. Ik aarzelde niet en plande direct een afspraak in.
                </p>

                <p class="py-2">
                    Helaas konden zij me op dat moment geen baan aan bieden als Software Developer, maar wel als Project Manager.
                    Omdat ik werkzoekende was had ik besloten om deze functie te dragen. Er is vaak besproken om mij te betrekken in het
                    ontwikkelen van websites/applicaties, maar helaas is er nooit iets echt van gekomen.
                </p>

                <p class="py-2">
                    Dit is ook de reden, waarom ik per augustus niet meer werkzaam ben binnen het bedrijf, omdat ik graag als ontwikkelaar
                    wil doorgaan!
                </p>
            </div>
        </section>

        <section class="bg-gray-100 py-10">
            <div class="max-w-7xl mx-auto text-gray-700 px-4 lg:px-0 text-center font-bold">
                <p class="py-2">
                    Ben je na het lezen van dit bericht nog steeds niet overtuigd dat ik je toekomstige medewerker of collega wordt?
                </p>

                <p class="pt-10">
                    <i class="fa-solid fa-arrow-right-long ml-3 animate-pulse text-2xl text-blue-700 mr-1"></i>
                    <inertia-link
                        href="/curriculum-vitae"
                        class="py-4 px-10 bg-gradient-to-r from-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-600 rounded uppercase text-white shadow">Bekijk Mijn CV</inertia-link>
                </p>
            </div>
        </section>
    </page-component>
</template>
<script>
import PageComponent from "../Components/PageComponent";

export default {
    name: "About",
    components: {
        PageComponent
    }
}
</script>

<style scoped>

</style>
