<template>
    <page-component isActive="curriculum-vitae">
        <section>
            <div class="max-w-7xl mx-auto">
                <div class="h-96 bg-gradient-to-bl from-blue-400 to-indigo-700 rounded">
                    <div class="pt-56 text-center text-white">
                        <h1 class="text-4xl">CURRICULUM VITAE</h1>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-10">
            <div class="max-w-7xl mx-auto text-gray-700 px-4 lg:px-0 overflow-x-auto">

                <h2 class="text-2xl font-semibold text-black py-4">Opleiding</h2>

                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Datum
                        </th>
                        <th scope="col" class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Onderdeel
                        </th>
                        <th scope="col" class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Diploma
                        </th>
                    </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <tr>
                            <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                2017 - 2020
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <p><span class="font-bold">Applicatie en Media- ontwikkeling MBO4</span>, ROC de Leijgraaf, Oss</p>

                                Kerntaken:
                                <ul>
                                    <li>- Levert een bijdrage aan het ontwikkeltraject</li>
                                    <li>- Realiseert en test een product</li>
                                    <li>- Opleveren van een product</li>
                                    <li>- Onderhoudt en beheert de applicatie</li>
                                </ul>
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <p><span class="px-4 py-2 bg-green-500 text-green-800 rounded">Behaald</span></p>
                            </td>
                        </tr>

                        <tr>
                            <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                2009 - 2012
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <p><span class="font-bold">ICT – Applicatieontwikkeling MBO4</span>, ROC de Leijgraaf, Oss</p>
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <p><span class="px-4 py-2 bg-gray-300 text-gray-800 rounded">Niet Behaald</span></p>
                            </td>
                        </tr>

                        <tr>
                            <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                2005 - 2009
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <p>VMBO – Kadergericht Udenscollege, Uden</p>
                            </td>
                            <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                                <p><span class="px-4 py-2 bg-green-500 text-green-800 rounded">Behaald</span></p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="bg-gray-100 py-10">
            <div class="max-w-7xl mx-auto text-gray-700 px-4 lg:px-0 overflow-x-auto">
                <h2 class="text-2xl font-semibold text-black py-4">Werkervaring</h2>

                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Datum
                        </th>
                        <th scope="col" class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Functie
                        </th>
                        <th scope="col" class="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Locatie
                        </th>
                    </tr>
                    </thead>
                    <tbody class="bg-gray-100 divide-y divide-gray-200">
                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2020 - 2021
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Project Manager & jr Software Developer</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Lanthopus B.V., Veghel</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2020 - 2020
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Jr Software developer – Stage</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Quadira, Veghel</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2019 - 2020
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Software Developer</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>DreamHack AB, Zweden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2019 - 2019
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Jr Software Developer</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Quadira, Veghel</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2018 - 2018
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Project Manager</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Lanthopus B.V., Veghel</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2018 - 2018
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Software Developer - Stage</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Lanthopus B.V., Veghel</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2017 - heden
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Twitch Partner / Streaming</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Uden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2015 - 2016
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Eerste mederwerker</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>De Eetkaamer, Uden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2014 - 2015
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Eerste mederwerker</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Eetkafee de Buren, Uden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2012 - 2014
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Medewerker evenementen</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>De Koppelen Catering, Beek en Donk</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2010 - 2011
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Medewerker ICT - Stage</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Udenscollege, Uden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2009 - 2014
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Baan- en Horecamedewerker</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Traxx, Uden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2007 - 2009
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Kok, Chinees afhaalrestaurant</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Finefood, Uden</p>
                        </td>
                    </tr>

                    <tr>
                        <td class="px-2 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            2008 - 2008
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Medewerker Elektrotechniek – Stage</p>
                        </td>
                        <td class="px-2 py-4 whitespace-nowrap text-sm text-gray-500">
                            <p>Paalman BV, Uden</p>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="py-10">
            <div class="max-w-7xl mx-auto text-gray-700 px-4 lg:px-0">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <h2 class="text-2xl font-semibold text-black pt-4">Talenkennis</h2>

                        <div class="relative pt-1">
                            Nederlands
                            <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                                <div style="width:100%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"></div>
                            </div>
                        </div>

                        <div class="relative pt-1">
                            Engels
                            <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-red-200">
                                <div style="width:100%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-red-500"></div>
                            </div>
                        </div>

                        <div class="relative pt-1">
                            Zweeds
                            <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-yellow-200">
                                <div style="width:50%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-yellow-500"></div>
                            </div>
                        </div>

                        <div class="relative pt-1 gap-4">
                            Duits
                            <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-pink-200">
                                <div style="width:25%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-pink-500"></div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h2 class="text-2xl font-semibold text-black pt-4">Overige</h2>
                        <ul class="mt-1">
                            <li><i class="fa-solid fa-circle-check text-green-600"></i> In bezit van rijbewijs B</li>
                            <li><i class="fa-solid fa-circle-check text-green-600"></i> In bezit van een auto</li>
                            <li><i class="fa-solid fa-circle-check text-green-600"></i> Mogelijkheid tot reizen</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-10 bg-gray-100">
            <div class="max-w-7xl mx-auto text-gray-700 px-4 lg:px-0">
                <h2 class="text-2xl font-semibold text-black pt-4 mb-1">Skills</h2>
                <p class="mb-2">
                    Ik heb gewerkt met de volgende software;
                </p>
                <div class="grid grid-cols-12 gap-4 text-3xl text-center">

                    <div>
                        <i class="fab fa-angular"></i>
                    </div>

                    <div>
                        <i class="fab fa-atlassian"></i>
                    </div>

                    <div>
                        <i class="fab fa-aws"></i>
                    </div>

                    <div>
                        <i class="fab fa-bitbucket"></i>
                    </div>

                    <div>
                        <i class="fab fa-bootstrap"></i>
                    </div>

                    <div>
                        <i class="fab fa-centos"></i>
                    </div>

                    <div>
                        <i class="fab fa-cloudflare"></i>
                    </div>

                    <div>
                        <i class="fab fa-css3"></i>
                    </div>

                    <div>
                        <i class="fab fa-docker"></i>
                    </div>

                    <div>
                        <i class="fab fa-github"></i>
                    </div>

                    <div>
                        <i class="fab fa-git"></i>
                    </div>

                    <div>
                        <i class="fab fa-gitlab"></i>
                    </div>

                    <div>
                        <i class="fab fa-html5"></i>
                    </div>

                    <div>
                        <i class="fab fa-jira"></i>
                    </div>

                    <div>
                        <i class="fab fa-js-square"></i>
                    </div>

                    <div>
                        <i class="fab fa-laravel"></i>
                    </div>

                    <div>
                        <i class="fab fa-linux"></i>
                    </div>

                    <div>
                        <i class="fab fa-magento"></i>
                    </div>

                    <div>
                        <i class="fab fa-mailchimp"></i>
                    </div>

                    <div>
                        <i class="fab fa-node-js"></i>
                    </div>

                    <div>
                        <i class="fab fa-npm"></i>
                    </div>

                    <div>
                        <i class="fab fa-openid"></i>
                    </div>

                    <div>
                        <i class="fab fa-php"></i>
                    </div>

                    <div>
                        <i class="fab fa-react"></i>
                    </div>

                    <div>
                        <i class="fab fa-sass"></i>
                    </div>

                    <div>
                        <i class="fab fa-trello"></i>
                    </div>

                    <div>
                        <i class="fab fa-ubuntu"></i>
                    </div>

                    <div>
                        <i class="fab fa-vuejs"></i>
                    </div>

                    <div>
                        <i class="fab fa-wordpress"></i>
                    </div>

                    <div>
                        <i class="fab fa-yarn"></i>
                    </div>
                </div>
            </div>
        </section>
    </page-component>
</template>
<script>
import PageComponent from "../Components/PageComponent";

export default {
    name: "Contact",
    components: {
        PageComponent
    }
}
</script>

<style scoped>

</style>
