<?php

return [
    'not_found' => 'Queue can not be found',
    'updated' => 'Queue has been updated',
    'removed' => 'Queue has been removed',
    'information' => 'Queue information',
    'id' => 'ID',
    'types' => 'Type',
    'total' => [
        'teams' => 'Total teams',
        'players' => 'Total players',
    ]
];
