<?php
return [
    'page' => [
        'content' => [
            'Hello there! My name is Wesley and I from The Netherlands.',
            'Since 2008 I have started to shown interest in the development of web applications. In 2009 I started
                an course in IT & Application development. The course did not offer me enough excitement - and
                did not meet my expectations. In 2012 I dropped out and started to work full-time in the catering industry.',
            'During that time I have never lost my interest in web development. In my off hours I was usually
                reading documentation of programming languages & frameworks and applied these too. The one that
                really stuck out is Laravel.',
            'After working full-time in the catering industry for 4 years I decided to change industries. At
                that time the game PLAYERUNKNOWN\'S BATTLEGROUND came out on PC in early access. I enjoyed playing
                this game a lot with my friends. When they announced that people were able to gain access to Custom Games
                (Ability to modify match settings) I did not hesitate and signed myself up.',
            'To start a match you need a lot of people to join. That\'s when I decided to start streaming on Twitch!
                This gave other people the ability to join my matches, plus that I was able to interact with them through
                the streams.',
            'This was still not it. I enjoyed it a lot but could not resist my feeling to become an actual programmer.
                Since I had not graduated and had not a portfolio of my self made/thought projects I could not find
                a suitable job in the industry. That\'s why I decided in June 2017 to apply once again for the same course as in 2009.',
            'So, we\'re back at school! Luckily I had a teacher that understood that I needed excitement and helped me
                throughout the course and that the basics were already known to me.',
            'In 2020 I graduated and started to work full time as Project Manager with aside junior Software Developer.
                After being employed for a year we have decided to go other directions. I was unable to show my full
                potential as developer and lost excitement.'
        ]
    ]
];
