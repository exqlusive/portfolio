<?php
return [
    'about' => 'About',
    'skills' => 'Skills',
];
