<?php
return [
    'about' => 'Over',
    'skills' => 'Skills',
    'contact' => 'Contact',
];
