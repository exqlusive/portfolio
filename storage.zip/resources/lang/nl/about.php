<?php
return [
    'page' => [
        'content' => [
            'Hallo daar! Mijn naam is Wesley en kom uit Nederland.',
            'Al sinds 2008 kreeg ik interesse in het ontwikkelen van websites. In 2009 ben ik een opleiding begonnen als ICT/Applicatie Ontwikkeling
                Helaas merkte ik al snel dat er geen uitdaging voor mij was in verband met dat ik al de basis kennis had opgedaan in mijn vrije tijd.
                Dit resulteerde er op dat ik vroeg met school gestopt was. Ik wou dolgraag in de branch van start gaan, maar helaas, door gebrek aan diploma
                en werkervaring heb ik toch voor gekozen om in de horeca te werken.',
            'Gedurende deze tijd ben ik nooit mijn interesse verloren in het ontwikkelen van web applicaties. Wanneer ik vrij van werk was,
                zag je me regelmatig door documentatie lezen en het toe te passen van nieuwe functionaliteiten. Het framework genaamd
                Laraval is sinds de eerste dag blijven hangen en vindt het een fijn framework om mee te werken.',
            'Na 4 jaar full time te hebben gewerkt in de horeca had ik besloten om hier mee te stoppen. Op dat moment kwam
                ook het spel genaamd PLAYERUNKNOWN\'S BATTLEGROUND uit op de computer. Ik vond dit een super tof spel om te spelen met
                vrienden en onbekenden. Toen ze bekend maakten dat mensen zichzelf konden opgeven om Custom Games toegang te krijgen
                (Mogelijkheid om spel aanpassingen te doen) aarzelde ik niet en gaf mijzelf hiervoor op.',
            'Om een spel te starten heb je een groot aantal spelers nodig. Dat was het moment dat ik bij mezelf dacht om te beginnen met het streamen op Twitch!
                Dit gaf anderen de kans om mee te spelen en kijken naar de spellen. Ook gaf dit mij de mogelijkheid om interactie te hebben met de kijkers.',
            'Ook al was dit een toffe tijd, was dit toch niet hetgene wat ik graag zou willen blijven doen. Bijkomend had ik het programmeren nooit opgegeven. In mijn
                vrije tijd deed ik dit nog steeds.
                Omdat ik nog geen diploma in de richting had en mijn portfolio niet aangevuld had met gemaakte applicaties kon ik op dat moment nog
                steeds geen baan vinden in de industrie. Ik heb in juni 2017 dus besloten om wederom de schoolbanken in de gaan net als in 2009 en voor de
                diploma te gaan!',
            'Daar zijn we weer! In de schoolbanken! Gelukkig had ik een vakdocent die begreep dat ik voor liep op de klasgenoten en zorgde voor andere opdrachten.',
            'In 2020 ben ik dan eindelijk geslaagd en heb ik mijn diploma op zak (Applicatie & Media-ontwikkeling).
                Eind augustus ben ik bij een bedrijf ingestapt als Project Manager in combinatie met Software Ontwikkeling. Helaas heb ik niet de juiste kans gekregen om mezelf
                te kunnen bewijzen als ontwikkelaar. Daarom hebben we na een jaar besloten om niet met elkaar verder te gaan.'
        ]
    ]
];
