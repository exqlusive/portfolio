<?php

use App\Http\Controllers\MenuController;
use App\Http\Controllers\PlayerController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\QueueController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Index');
});

Route::get('/login', function () {
    return Inertia::render('Login');
})->name('login');

Route::middleware(['auth'])->group(function () {
    Route::get('profile', [ProfileController::class, 'index']);
});

Route::get('discord/callback', [UserController::class, 'login']);

Route::get('/users', [UserController::class, 'index']);
Route::get('/players', [PlayerController::class, 'index']);
Route::get('/teams', [TeamController::class, 'index']);

Route::get('/queues', [QueueController::class, 'index']);
Route::get('/queues/{uuid}', [QueueController::class, 'read']);
Route::get('/queues/{uuid}/players', [QueueController::class, 'players']);

Route::get('/app/menu', [MenuController::class, 'index']);
